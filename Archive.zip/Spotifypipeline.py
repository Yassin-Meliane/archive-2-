import pandas as pd
import sqlite3

# Extract
df = pd.read_csv("Downloads/Legoset/archive (2)/spotify_songs.csv")

import pandas as pd
import matplotlib.pyplot as plt
#transfter data
spotify_data = pd.read_csv('Downloads/Thebrief/archive (2)/spotify_songs.csv')
spotify_data['track_album_release_date'] = pd.to_datetime(spotify_data['track_album_release_date'], errors='coerce', format='%Y-%m-%d')
#load data
spotify_data.to_csv('dwh/spofity.csv' , index=False)